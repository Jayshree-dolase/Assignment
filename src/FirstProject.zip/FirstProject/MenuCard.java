package FirstProject;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Random;
import java.util.Scanner;

class MenuCard{

public static void main(String[] args) {
	
	
	
}
}
