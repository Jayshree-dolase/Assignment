package FirstProject;
import FirstProject.Coures;
public class PannerMasala implements Panner {

	@Override
	public int  get(int TikkaQty, int MasalaRate) {
		// TODO Auto-generated method stub
		Coures c = new Coures();

	int	MasalaTotal=TikkaQty*MasalaRate;// TODO Auto-generated method stub
		
	      return MasalaTotal;
	}

}
