package FirstProject;

public interface Panner {

	public int	get(int quantity ,int rate);
}
