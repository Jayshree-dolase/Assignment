package FirstProject;

public class TestM {

	public static void main(String[] args) {
		Coures c = new Coures();
		c.displayMenu();
		c.selectMenu();
	
		
	}

}
