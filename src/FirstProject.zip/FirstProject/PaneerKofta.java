package FirstProject;
import FirstProject.Coures;
public class PaneerKofta implements Panner {
	Coures c = new Coures();
	@Override
	public int get(int KoftaQty, int Kofta_Rate) {
		// TODO Auto-generated method stub
		int KoftaTotal= KoftaQty*Kofta_Rate;
		return	KoftaTotal;
	}

}
